package com.moraspirit.moraspiritapp;

import android.annotation.SuppressLint;
import android.graphics.drawable.Animatable;
import android.os.Handler;
import android.support.design.bottomappbar.BottomAppBar;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import static android.view.View.VISIBLE;

public class MainActivity extends FragmentActivity {
    private BottomAppBar bottomAppBar;
    private FloatingActionButton floatingActionButton;
    private ViewPager viewPager;
    private PagerAdapter pagerAdapter;
    private int prevFragmentIindex = 0;
    private TextView title;
    private boolean firstTime;

    private static final int NUM_PAGES = 4;

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firstTime = true;

        title = findViewById(R.id.title);
        bottomAppBar = findViewById(R.id.bar);
        floatingActionButton = findViewById(R.id.fav);
        viewPager = findViewById(R.id.viewPager);

        bottomAppBar.replaceMenu(R.menu.bottomappbar_menu);
        pagerAdapter = new SlidePagerAdaptor(getSupportFragmentManager());
        viewPager.setAdapter(pagerAdapter);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                floatingActionButton.show();
            }
        }, 300);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
                switch (i) {
                    case 0:
                        if (!firstTime) {
                            title.setText("Articles");
                        } else {
                            title.setText("MoraSpirit");
                            firstTime = false;
                        }

                        floatingActionButton.setImageResource(R.drawable.ic_folded_newspaper);
                        break;
                    case 1:
                        title.setText("Gallery");
//                        floatingActionButton.setVisibility(View.VISIBLE);
//                        floatingActionButton.show();
                        floatingActionButton.setImageResource(R.drawable.ic_gallery);
                        break;
                    case 2:
                        title.setText("Rankings");
                        floatingActionButton.setImageResource(R.drawable.ic_medal);
                        break;
                    case 3:
                        title.setText("About");
                        floatingActionButton.setImageResource(R.drawable.ic_info_outline_black_24dp);
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (viewPager.getCurrentItem() == NUM_PAGES - 1) {
                    setFragment(0);
                } else if (viewPager.getCurrentItem() == NUM_PAGES - 2) {
                    setFragment(0);
                } else {
                    setFragment(viewPager.getCurrentItem() + 1);
                }

            }
        });
        bottomAppBar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                floatingActionButton.show();

                if (menuItem.getItemId() == R.id.about) {
                    if (viewPager.getCurrentItem() != NUM_PAGES - 1) {
                        setFragment(NUM_PAGES - 1);
                    } else {
                        setFragment(prevFragmentIindex);
                    }
                }
                return false;
            }
        });

    }

    @Override
    public void onBackPressed() {

        if (viewPager.getCurrentItem() == 0) {
            floatingActionButton.hide();
            super.onBackPressed();
        } else if (viewPager.getCurrentItem() == NUM_PAGES - 1) {
            setFragment(0);
        } else {
            setFragment(viewPager.getCurrentItem() - 1);
        }
    }

    public void setFragment(int position) {
        prevFragmentIindex = viewPager.getCurrentItem();
        viewPager.setCurrentItem(position);
    }

    public class SlidePagerAdaptor extends FragmentStatePagerAdapter {

        public SlidePagerAdaptor(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0:
//                    title.setText("Articles");
                    return new ArticleFragment();
                case 1:
//                    title.setText("Gallery");
                    return new GalleryFragment();
                case 2:
//                    title.setText("Rankings");
                    return new RankingFragment();
                case 3:
//                    title.setText("About");
                    return new AboutFragment();
            }
            return null;
        }

        @Override
        public int getCount() {
            return NUM_PAGES;
        }

    }
}
